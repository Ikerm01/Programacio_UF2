'''Crea un paquet anomenat "stats" que contingui una classe anomenada "Statistics"
amb una funció estàtica que calculi la desviació estàndard d'una llista de nombres.
Utilitza l'algorisme correctament i gestiona els casos especials. (RA: 1.1, 1.2, 1.4)'''

'''
1.Crear una classe anomenada "Statistics"
2.Calcular la desviacio estandard d'una llista de nombre.
2.1 Calcular la mitjana 
2.2 Calcular la suma de la diferencias amb la mitjana
2.3 Calcular la desviacio estandar
2.1.1 sumar tots el numeros i dividir per la cantitat de elements
2.2.1 Fer la resta de cada numero de la mitjana i elevarla al quadrat i sumar els resultats
'''
numeros = [1,2,3,4,5]

class statistics:
    def desviacio_estandard(numeros):
        #2.1 Calcular la mitjana 
        mitjana = sum(numeros) / len(numeros)
        #2.2 Calcular la suma de la diferencias amb la mitjana
        diferencia_mitjana = sum ((x - mitjana) ** 2 for x in numeros)
        #2.3 Calcular la desviacio estandar
        cal_desviacio_estandard = (diferencia_mitjana / len(numeros)) ** 0.5

        return cal_desviacio_estandard
