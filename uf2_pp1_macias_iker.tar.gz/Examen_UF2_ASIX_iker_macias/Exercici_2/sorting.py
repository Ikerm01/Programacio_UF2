'''Crea un paquet anomenat "sorting" que contingui una classe anomenada "Sorting"
amb una funció que ordeni una llista de nombres de menor a major utilitzant un
algorisme d'ordenació eficient com ara QuickSort o MergeSort. (RA: 1.3, 1.5)'''

'''
1.Ordenar una llista de nombres de menor a major
1.1 Utilizar Bubble sort per ordenar la llista
1.1.2 Iterar sobre una llista de numeros
1.1.3 Comparar amb el seguent numero
1.1.4 Si el numero actual es mes gran que el seguent sustituirlo
'''
numeros = [5,2,3,7,8,1]

class Sorting:
    def ordenar_llista(numeros):
        numero = len(numeros)
        for i in range(numero):
            for j in range(0, numero-i-1):
                if numeros[j] > numeros[j+i]:
                    numeros[j], numeros[j+1] = numeros[j+1], numeros[j]
                else:
                    break
print(numeros)
